$(document).ready(function () {
    $("#txtdate").datepicker({
        minDate: 0,
        // ...
    });
});