 
    // $("#toggle").spectrum({
    //     color: "rgb(255, 235, 205)"
    // });
    // $("#colorpicker").spectrum({
    //     color: "#f00"
    // });

    $(".colorpicker").spectrum({
        color: "yellow"
    });